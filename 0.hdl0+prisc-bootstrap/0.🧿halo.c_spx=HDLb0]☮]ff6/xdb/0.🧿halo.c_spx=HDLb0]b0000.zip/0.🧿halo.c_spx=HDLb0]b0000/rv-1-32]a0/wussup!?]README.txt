
❤️‍🩹️
rv1- dont just start making add.er make the registers first. u know u can test them 
sure make it but ask questions after or w/e 
get some stuff manually b4 u try 2 get slic (the emulator def works tho d_latch works) ❤️‍🩹️
